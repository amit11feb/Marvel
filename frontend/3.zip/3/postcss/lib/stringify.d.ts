import { Stringifier } from './postcss.js'

declare const stringify: Stringifier

export default stringify
