// eslint-disable-next-line no-eval
export default function (code) { return eval(code); };
