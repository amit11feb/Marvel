import Mime = require('./Mime');

declare const mimelite: Mime;

export as namespace mimelite;

export = mimelite;
